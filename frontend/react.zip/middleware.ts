import { NextResponse } from 'next/server'
export function middleware(req:any){const p=req.nextUrl.pathname; if(p.startsWith('/upload')||p.startsWith('/status')){const a=req.cookies.get('__Host-access')?.value; if(!a){const to=new URL('/api/auth/login',req.url); to.searchParams.set('returnTo',p+req.nextUrl.search); return NextResponse.redirect(to)}} return NextResponse.next()}
export const config={matcher:['/upload','/status']}
