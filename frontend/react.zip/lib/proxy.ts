import { cookies } from 'next/headers'
function upstream(p:string){return (process.env.API_BASE||'').replace(/\/$/,'')+p}
export async function proxyPost(path:string, body:any){const a=cookies().get('__Host-access')?.value;if(!a)return new Response('Unauthorized',{status:401});const r=await fetch(upstream(path),{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${a}`},body:JSON.stringify(body)});return new Response(await r.text(),{status:r.status,headers:{'content-type':r.headers.get('content-type')||'application/json'}})}
