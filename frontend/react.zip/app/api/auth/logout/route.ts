import { NextResponse } from 'next/server'
export const runtime='nodejs'
export async function GET(req:Request){const u=new URL(req.url);const r=new NextResponse(null,{status:302});r.cookies.set('__Host-access','',{path:'/api',maxAge:0});r.cookies.set('__Host-refresh','',{path:'/api/auth',maxAge:0});const lo=new URL(process.env.COGNITO_DOMAIN!+'/logout');lo.searchParams.set('client_id',process.env.COGNITO_CLIENT_ID!);lo.searchParams.set('logout_uri',u.origin+'/signin');r.headers.set('Location',lo.toString());return r}
