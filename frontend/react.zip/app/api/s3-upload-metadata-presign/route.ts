import { proxyPost } from '@/lib/proxy'
export const runtime='nodejs'
export async function POST(req:Request){const b=await req.json();return proxyPost('/s3-upload-metadata-presign',b)}
