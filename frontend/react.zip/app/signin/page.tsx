import Link from 'next/link'
export default function SignIn(){return(<div className="container-narrow py-12"><div className="card p-8 max-w-xl mx-auto">
<h1 className="text-xl font-semibold mb-3">Sign in</h1><p className="text-sm text-zinc-600 mb-6">Use Cognito Hosted UI (Code+PKCE).</p>
<div className="flex gap-3"><Link className="btn btn-primary" href="/api/auth/login">Sign in with Cognito</Link><Link className="btn btn-secondary" href="/api/auth/logout">Sign out</Link></div>
</div></div>)}
