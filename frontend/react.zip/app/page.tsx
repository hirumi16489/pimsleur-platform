import Link from 'next/link'
export default function Page(){return(<div className="container-narrow py-12">
  <div className="card p-8 max-w-2xl mx-auto">
    <h1 className="text-xl font-semibold mb-4">Home (public)</h1>
    <p className="text-sm text-zinc-600 mb-6">Next.js SSR starter for S3 uploads.</p>
    <div className="flex gap-3">
      <Link className="btn btn-primary" href="/signin">Sign in</Link>
      <Link className="btn btn-secondary" href="/upload">Upload</Link>
      <Link className="btn btn-secondary" href="/status">Status</Link>
    </div>
  </div>
</div>)}
