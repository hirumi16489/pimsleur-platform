'use client'
import { useMemo, useState } from 'react'

type Presigned = { url: string; headers?: Record<string,string> }
type Uploaded = { name: string; size: number; contentType: string; etag?: string }

export default function UploadPage(){
  const [files,setFiles]=useState<File[]>([])
  const [busy,setBusy]=useState(false)
  const [error,setError]=useState<string|null>(null)

  const sorted=useMemo(()=>{const a=[...files];a.sort((x,y)=>(x.name==='metadata.json'?1:0)-(y.name==='metadata.json'?1:0));return a},[files])

  async function presign(f:File):Promise<Presigned>{
    const r=await fetch('/api/s3-upload-presign',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({name:f.name,contentType:f.type||'application/octet-stream'})})
    if(!r.ok) throw new Error('presign failed '+f.name); return r.json()
  }
  async function put(f:File,p:Presigned){return new Promise<Uploaded>((res,rej)=>{const x=new XMLHttpRequest();x.open('PUT',p.url);if(p.headers)for(const[k,v]of Object.entries(p.headers))x.setRequestHeader(k,v);if(!p.headers||!('Content-Type'in p.headers))if(f.type)x.setRequestHeader('Content-Type',f.type);x.onload=()=>x.status>=200&&x.status<300?res({name:f.name,size:f.size,contentType:f.type||'application/octet-stream',etag:x.getResponseHeader('ETag')||undefined}):rej(new Error('HTTP '+x.status));x.onerror=()=>rej(new Error('network'));x.send(f)})}

  async function start(){try{
    setBusy(true);setError(null)
    const assets=sorted.filter(f=>f.name!=='metadata.json')
    const uploaded:Uploaded[]=[]
    for(const f of assets){const p=await presign(f);uploaded.push(await put(f,p))}
    const payload={createdAt:new Date().toISOString(),files:uploaded}
    const m=await fetch('/api/s3-upload-metadata-presign',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({name:'metadata.json',contentType:'application/json',metadata:payload})})
    if(!m.ok) throw new Error('metadata presign failed'); const meta=await m.json() as Presigned
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'})
    await put(new File([blob],'metadata.json',{type:'application/json'}),meta)
    window.location.href='/status'
  }catch(e:any){setError(e.message||String(e));setBusy(false)}}

  return(<div className="container-narrow py-12"><div className="card p-8 max-w-2xl mx-auto">
    <h1 className="text-xl font-semibold mb-4">Upload (protected)</h1>
    <p className="text-sm text-zinc-600 mb-6">Select files, each will get a presigned URL. Then we upload <code>metadata.json</code> summarizing them.</p>
    <input type="file" multiple onChange={e=>setFiles(Array.from(e.target.files||[]))} />
    {files.length>0 && <ul className="mt-6 space-y-2">{sorted.map((f,i)=>(<li key={i} className="p-3 border rounded-xl bg-white"><div className="text-sm font-medium">{f.name}</div><div className="text-xs text-zinc-500">{(f.size/1024).toFixed(1)} KB</div></li>))}</ul>}
    <div className="mt-6 flex gap-3"><button className="btn btn-secondary" onClick={()=>setFiles([])} disabled={busy}>Reset</button><button className="btn btn-primary" onClick={start} disabled={busy||files.length===0}>{busy?'Uploading…':'Start upload'}</button></div>
    {error && <div className="mt-4 text-sm text-red-600">{error}</div>}
  </div></div>)
}
