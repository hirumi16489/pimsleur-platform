import './globals.css'
export const metadata={title:'Upload Starter',description:'Next.js SSR + S3 presign'}
export default function RootLayout({children}:{children:React.ReactNode}){
  return <html lang="en"><body className="bg-zinc-50 text-zinc-900">{children}</body></html>
}
